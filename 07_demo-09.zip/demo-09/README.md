# Objetivos del repositorio

Este proyecto se encarga de gestionar los planes de la liga de la justicia

# Notas

Podemos hacer lo que queramos en este repositorio
