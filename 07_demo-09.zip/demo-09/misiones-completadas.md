# Misiones

* Crear la liga de la justicia
* Comprar pizza
* Investigar qué trama Flash Reverso
* Encontrar un lugar de alquiler para la liga de la justicia
